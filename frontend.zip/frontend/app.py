import streamlit as st
import sys
import os
import glob

# Add path for agents import
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from agents.coordinator_agent import CoordinatorAgent

# App config
st.set_page_config(page_title="Agentic RAG Chatbot", layout="wide")
st.title("🤖 Agentic RAG Chatbot")
st.markdown("Upload documents and ask questions based on their content.")

# Upload dir setup
UPLOAD_DIR = "data/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# File upload UI
uploaded_files = st.file_uploader("Upload your documents (PDF, DOCX, PPTX, CSV, TXT)", accept_multiple_files=True)

if uploaded_files:
    for uploaded_file in uploaded_files:
        file_path = os.path.join(UPLOAD_DIR, uploaded_file.name)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
    st.success(f"✅ {len(uploaded_files)} file(s) uploaded.")

# User query
query = st.text_input("💬 Ask a question:")
files = glob.glob(f"{UPLOAD_DIR}/*")

if st.button("Ask"):
    if not query.strip():
        st.warning("⚠️ Please enter a valid question.")
    elif not files:
        st.warning("⚠️ Please upload at least one document.")
    else:
        coordinator = CoordinatorAgent()
        final_msg = coordinator.handle_user_query(files, query)

        if final_msg is None or "payload" not in final_msg:
            st.error("❌ Something went wrong during answer generation.")
        else:
            st.markdown("### 🤖 Answer:")
            st.markdown(final_msg["payload"]["answer"])

            with st.expander("🧠 Source Chunks"):
                for src in final_msg["payload"]["sources"]:
                    st.markdown(f"> {src}")
